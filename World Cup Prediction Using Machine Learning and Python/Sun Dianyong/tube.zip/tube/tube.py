# -*- coding: utf-8 -*-

#任务1：获得站点信息
#1.1：引用库，并获得网页资源
import re
from urllib import request
from bs4 import BeautifulSoup
import time
from timeit import timeit
officialsubway=request.urlopen('http://www.bjsubway.com/station/xltcx/')#打开网页
subwayread=officialsubway.read().decode('gbk')#解码
BS1=BeautifulSoup(subwayread,'html.parser')
lineContent=BS1.find_all('',{'class':re.compile('subway_name|station|line_name')})

#1.2：建立相关list及dict
subList=[]  #储存线路以及站名
lineList=[]  #储存线路名称在sublist的位置
lineDict={}  #建立线路所对应站点

#1.3：存储所有站点、地铁线文字信息
for i in lineContent:
    subList.append(i.get_text())

for i in subList:
    if '线' in i:
            lineList.append(subList.index(i))  #特别地，记录“地铁线”名所在list的位置

#1.4：消除异常数据文本
for i in lineList:
    if '\u3000' in subList[i]:
        subList[i]=subList[i][:-13]+'\n'
    subList[i]=subList[i][1:-1]

#1.5：对每个“地铁线”，在字典中以list存储其包含的所有站名
for i in range(0,19):
    lineDict[subList[lineList[i]]]=subList[lineList[i]+1:lineList[i+1]]

lineDict[subList[lineList[19]]+"1线"]=subList[lineList[19]+1:]  #最后一个地铁线S1线，由于数据形式特殊，进行特别处理，以统一存储格式
lineDict['2号线'].append('西直门')  #环线特殊处理，在末尾添加首站信息
lineDict['10号线'].append('巴沟')  #环线特殊处理，在末尾添加首站信息

#1.5.5：14号线特殊处理（地铁官网上站名混乱）
lineDict["14W号线"]=lineDict["14号线"][:7]
lineDict["14E号线"]=['北京南站','永定门外','景泰','蒲黄榆','方庄','十里河','北工大西门','九龙山','大望路','金台路','朝阳公园','枣营','东风北桥','将台','望京南','阜通','望京','东湖渠','来广营','善各庄']
lineDict.pop("14号线")
"""
#1.6：删除中间进程
del subList,lineList,officialsubway,subwayread,BS1,lineContent

#任务2：建立站间“图结构”
#建立图结构，使计算机知晓每一步可能的下一站

#2.1：站点数组建立（方便接下来为每个站点建立各自相邻站点信息集）
StationSet=set()
for i in lineDict:
    StationSet=StationSet|set(lineDict[i])#得到所有站点

#2.2：录入每个站点相连站点信息（站名+所属地铁线）
subwayDict={}
for i in StationSet:
    subwayDict[i]={}

def graphSystem(lineName,stationList):#建立图结构所需参数
    lineLength=len(stationList)  #该地铁线共有几站（环线多一站）
    for i in range(1,lineLength-1):
        subwayDict[stationList[i]][stationList[i-1]]=lineName
        subwayDict[stationList[i]][stationList[i+1]]=lineName
    subwayDict[stationList[0]][stationList[1]]=lineName #首特殊处理
    subwayDict[stationList[lineLength-1]][stationList[lineLength-2]]=lineName #尾特殊处理

for i in lineDict:
    graphSystem(i,lineDict[i])

#任务3：生成前100种合理路径（基本涵盖所有）
#借鉴http://blog.csdn.net/myjiayan/article/details/45954679

def Path(begin,goal):
    myPath=[] #最终筛选得到的路径
    count=0
    if begin==goal:
        return [begin]#直接到站

    pathQueue=[[begin]]#从一点出发的所有路径，向外拓展

    while pathQueue:
        pathOne=pathQueue.pop(0)#首位踢出队列
        i=pathOne[-1]
        if i==goal:
            myPath.append(pathOne)#检测是否到站
            if len(myPath)==100:#筛选前百种路径
                return myPath

        for station,line in subwayDict[i].items():
            if station not in pathOne:#防止回走
                pathTwo=pathOne+[line,station]#向外拓展一位
                pathQueue.append(pathTwo)
    return []

#任务4：根据“最少换乘”、“最短距离”、“最少用时”分别设计对不同路线方案排序的函数

#4.1：<最少换乘>排序函数
def change(path):
    line=[]
    for i in range(0,len(path)):
        if i%2==1:
            line.append(path[i])
    return len(set(line))

def LeastTrans(paths):
    paths.sort(key=lambda x: change(x))
    return paths[0]

#4.2：<最短距离>排序函数
#4.2.1：坐标信息库
import requests
import json
import math
#创建坐标记录字典
locationDict={}
#通过百度地图API获取各站点坐标数据
html=requests.get(r'http://map.baidu.com/?qt=bsi&c=131&t=1469072745455')
hjson=json.loads(html.content)
#爬取各个线路各个站点坐标数据，并记录入字典中
for i in hjson['content']:
    for stop in i['stops']:
        x=stop['x']/20037508.3427892 * 180
        y=stop['y']/20037508.3427892 * 180
        y = 180 / math.pi * (2 * math.atan(math.exp(y * math.pi / 180)) - math.pi / 2)
        locationDict[stop['name']]=(x,y)

#4.2.2：坐标换算距离函数
from math import radians, cos, sin, asin, sqrt

def haversine(lon1, lat1, lon2, lat2):  # 经度1，纬度1，经度2，纬度2 （十进制度数）
#Calculate the great circle distance between two points on the earth (specified in decimal degrees)
#借鉴https://blog.csdn.net/vernice/article/details/46581361
    # 将十进制度数转化为弧度
    lon1, lat1, lon2, lat2 = map(radians, [lon1, lat1, lon2, lat2])
    # haversine公式
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    a = sin(dlat / 2) ** 2 + cos(lat1) * cos(lat2) * sin(dlon / 2) ** 2
    c = 2 * asin(sqrt(a))
    r = 6371  # 地球平均半径，单位为公里
    return c * r #返回单位为公里

#4.2.3：计算每一种可能路线的总行驶距离的函数
def distance(path):
    sum=0
    line = []
    for i in range(0, len(path)):
        if i % 2 == 0:
            line.append(path[i])
    for i in range(len(set(line))-1):
        sum+=haversine(locationDict[line[i]][0],locationDict[line[i]][1],locationDict[line[i+1]][0],locationDict[line[i+1]][1])
    return sum

#4.2.4：实现路程排序
def LeastDistance(paths):
    paths.sort(key=lambda x: distance(x))
    return paths[0]

#4.3：<最少用时>排序
# 根据地铁平均时速36km/h及每次换乘平均花费3分钟，计算每种路径总预估时间并排序
#4.3.1：计算每一种可能路线的总行驶时间的函数
def time(path):
    time=0
    time=distance(path)/36+change(path)*0.06
    return time

def LeastTime(paths):
    paths.sort(key=lambda x: time(x))
    return paths[0]

#任务5：用flask进行可视化输出及交互
#5.1：引入相关库
from flask import Flask,render_template,request

#5.2：程序输出
app=Flask(__name__)

@app.route('/')
def root():
    return render_template('webpage.html')

@app.route('/inquire',methods=['get','post'])
def inquire():
    begin=request.form['begin']
    goal=request.form['goal']
    option = request.form['option']
    words=''
    pathone=LeastTrans(Path(begin,goal))
    pathtwo=LeastDistance(Path(begin,goal))
    paththree=LeastTime(Path(begin,goal))  #分别对应3种路径特点，生成对应的最佳线路
    if option=='最少换乘':  #根据不同的选择，返回不同的推荐路线
        stationList = []
        lineList = []
        for i in range(0, len(pathone)):
            if i % 2 == 0:
                stationList.append(pathone[i])
            else:
                lineList.append(pathone[i])
        words = stationList[0] + '乘' + lineList[0] + '\n'
        for i in range(1, len(lineList)):
            if lineList[i] != lineList[i - 1]:
                words = words + '至' + stationList[i] + '转' + lineList[i] + '\n'
        words = words + '终到' + stationList[-1] + ' ,共计换乘' + str(change(pathone)) + '次'
    elif option=='最短距离':
        stationList = []
        lineList = []
        for i in range(0, len(pathtwo)):
            if i % 2 == 0:
                stationList.append(pathtwo[i])
            else:
                lineList.append(pathtwo[i])
        words = stationList[0] + '乘' + lineList[0] + '\n'
        for i in range(1, len(lineList)):
            if lineList[i] != lineList[i - 1]:
                words = words + '至' + stationList[i] + '转' + lineList[i] + '\n'
        words = words + '终到' + stationList[-1] + ' ,共计路程' + str(round(distance(pathone), 2)) + '公里'
    elif option == '最少用时':
        stationList = []
        lineList = []
        for i in range(0, len(paththree)):
            if i % 2 == 0:
                stationList.append(paththree[i])
            else:
                lineList.append(paththree[i])
        words = stationList[0] + '乘' + lineList[0] + '\n'
        for i in range(1, len(lineList)):
            if lineList[i] != lineList[i - 1]:
                words = words + '至' + stationList[i] + '转' + lineList[i] + '\n'
        words = words + '终到' + stationList[-1] + ' ,预计用时' + str(round(time(pathone) * 60, 2)) + '分钟'
    return render_template('webpage.html',result=words)
#5.3：程序运行
if __name__=='__main__':
    app.run()

#eof
"""